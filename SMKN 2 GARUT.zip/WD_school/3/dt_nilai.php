				<thead>
					<tr>
						<th>Siswa</th>
						<th>Mata Pelajaran</th>
						<th>Nilai UTS</th>
						<th>Nilai UAS</th>
						<th>Nilai Ahir</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$querynilai = mysqli_query ($konek, "SELECT Id_Nilai, NISN_Nilai, Kode_matapelajaran_Nilai, Nilai, NISN,Nilai_uts,Nilai_uas, Nama_siswa, Kode_matapelajaran, Nama_matapelajaran FROM nilai
										INNER JOIN siswa ON NISN_Nilai=NISN
										INNER JOIN matapelajaran ON Kode_matapelajaran_Nilai=Kode_matapelajaran WHERE NISN_Nilai='$_SESSION[Username]'");
						if($querynilai == false){
							die ("Terjadi Kesalahan : ". mysqli_error($konek));
						}
						while ($nilai = mysqli_fetch_array ($querynilai)){
							
							echo "
								<tr>
									<td>$nilai[Nama_siswa]</td>
									<td>$nilai[Nama_matapelajaran]</td>
									<td>$nilai[Nilai_uts]</td>
									<td>$nilai[Nilai_uas]</td>
									<td>$nilai[Nilai]</td>
								</tr>";
						}
					?>
				</tbody>