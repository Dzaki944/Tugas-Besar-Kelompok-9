<?php

include "../koneksi.php";

$Id_Nilai				= $_POST["Id_Nilai"];
$NISN_Nilai				= $_POST["NISN_Nilai"];
$Nilai					= $_POST["Nilai"];
$Nilai_uts				= $_POST["Nilai_uts"];
$Nilai_uas				= $_POST["Nilai_uas"];

if($edit = mysqli_query($konek, "UPDATE nilai SET NISN_Nilai='$NISN_Nilai' ,Nilai_uts='$Nilai_uts',Nilai_uas='$Nilai_uas' ,Nilai='$Nilai' WHERE Id_Nilai='$Id_Nilai'")){
	header("Location: nilai.php");
	exit();
}
die("Terdapat Kesalahan : ". mysqli_error($konek));

?>