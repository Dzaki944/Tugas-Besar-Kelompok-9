<?php

include "../koneksi.php";

$NISN_Nilai				= $_POST["NISN_Nilai"];
$Kode_matapelajaran_Nilai	= $_POST["Kode_matapelajaran_Nilai"];
$Nilai					= $_POST["Nilai"];
$Nilai_uts				= $_POST["Nilai_uts"];
$Nilai_uas				= $_POST["Nilai_uas"];

if($add = mysqli_query($konek, "INSERT INTO nilai (NISN_Nilai, Kode_matapelajaran_Nilai, Nilai,Nilai_uts,Nilai_uas) VALUES ('$NISN_Nilai', '$Kode_matapelajaran_Nilai', '$Nilai', '$Nilai_uts', '$Nilai_uas')")){
	header("Location: nilai.php");
	exit();
}
die("Terdapat Kesalahan : ". mysqli_error($konek));

?>