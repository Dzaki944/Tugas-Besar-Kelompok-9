<?php

include "../koneksi.php";

$Id_Nilai	= $_GET["Id_Nilai"];

$daftarnilai[] = "A";
$daftarnilai[] = "B";
$daftarnilai[] = "C";
$daftarnilai[] = "D";

$querynilai = mysqli_query($konek, "SELECT * FROM nilai WHERE Id_Nilai='$Id_Nilai'");
if($querynilai == false){
	die ("Terjadi Kesalahan : ". mysqli_error($konek));
}
while($nilai = mysqli_fetch_array($querynilai)){

?>
	
	<script src="../aset/plugins/daterangepicker/moment.min.js"></script>
	<script src="../aset/plugins/daterangepicker/daterangepicker.js"></script>
	<!-- page script -->
    <script>
      $(function () {	
		// Daterange Picker
		  $('#Tanggal_Lahir2').daterangepicker({
			  singleDatePicker: true,
			  showDropdowns: true,
			  format: 'YYYY-MM-DD'
		  });
      });
    </script>
<!-- Modal Popup Guru -->
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title">Edit Nilai</h4>
					</div>
					<div class="modal-body">
						<form action="nilai_edit.php" name="modal_popup" enctype="multipart/form-data" method="post">
							<input type="hidden" name="Id_Nilai" value="<?php echo $nilai["Id_Nilai"]; ?>">
							<div class="form-group">
								<label>Siswa</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-users"></i>
										</div>
										<select name="NISN_Nilai" class="form-control">
										<?php
										
											$querynilaimhs = mysqli_query($konek, "SELECT NISN_Nilai, NISN, Nama_siswa FROM nilai INNER JOIN siswa ON NISN_Nilai=NISN WHERE Id_Nilai='$Id_Nilai'");
											if($querynilaimhs == false){
												die("Terdapat Kesalahan : ". mysqli_query($konek));
											}
											while($nilaimhs = mysqli_fetch_array($querynilaimhs)){
												echo "<option value='$nilaimhs[NISN_Nilai]' selected>$nilaimhs[Nama_siswa]</option>";
											}
											
											$querymhs = mysqli_query($konek, "SELECT * FROM siswa");
											if($querymhs == false){
												die("Terdapat Kesalahan : ". mysqli_error($konek));
											}
											while($mhs = mysqli_fetch_array($querymhs)){
												if($mhs["NISN"] != $nilai["NISN_Nilai"]){
													echo "<option value='$mhs[NISN]'>$mhs[Nama_siswa]</option>";
												}
											}
										?>
										</select>
									</div>
							</div>
							 

							<div class="form-group">
								<label>Nilai Uts</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<input name="Nilai_uts" type="text" class="form-control" value="">
									</div>
							</div>

							<div class="form-group">
								<label>Nilai Uas</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<input name="Nilai_uas" type="text" class="form-control" value="">
									</div>
							</div>

							

							<div class="form-group">
								<label>Nilai</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<select name="Nilai" class="form-control">
										<?php
										
										echo "<option value='$nilai[Nilai]' selected>$nilai[Nilai]</option>";
											for($nilai=0; $nilai<count($daftarnilai); $nilai++){
												if($nilai["Nilai"] != $daftarnilai[$nilai])
												{
													echo "<option value='$daftarnilai[$nilai]'>$daftarnilai[$nilai]</option>";
												}
												
											}
										?>
										</select>
									</div>
							</div>

							<div class="modal-footer">
								<button class="btn btn-success" type="submit">
									Save
								</button>
								<button type="reset" class="btn btn-danger"  data-dismiss="modal" aria-hidden="true">
									Cancel
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			
			
<?php
			}

?>