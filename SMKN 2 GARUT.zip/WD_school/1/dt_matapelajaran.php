				<thead>
					<tr>
						<th>Kode MataPelajaran</th>
						<th>Nama MataPelajaran</th>
					<!-- <th>SKS</th> -->
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$querymatapelajaran = mysqli_query ($konek, "SELECT * FROM matapelajaran");
						if($querymatapelajaran == false){
							die ("Terdapat Kesalahan : ". mysqli_error($konek));
						}
						while($matapelajaran = mysqli_fetch_array($querymatapelajaran)){
							echo "
								<tr>
									<td>$matapelajaran[Kode_matapelajaran]</td>
									<td>$matapelajaran[Nama_matapelajaran]</td>
									<td>
										<a href='#' class='open_modal' id='$matapelajaran[Kode_matapelajaran]'>Edit</a> |
										<a href='#' onClick='confirm_delete(\"matapelajaran_delete.php?Kode_matapelajaran=$matapelajaran[Kode_matapelajaran]\")'>Delete</a>
									</td>
								</tr>";
						}
					?>
				</tbody>