<?php

include "../koneksi.php";

$NISN = $_GET["NISN"];

if($delete = mysqli_query($konek, "DELETE FROM siswa WHERE NISN='$NISN'")){
	header("Location: siswa.php");
	exit();
}
die ("Terdapat Kesalahan : ".mysqli_error($konek));

?>