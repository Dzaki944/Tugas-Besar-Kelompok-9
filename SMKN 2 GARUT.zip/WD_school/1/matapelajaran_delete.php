<?php

include "../koneksi.php";

$Kode_matapelajaran	= $_GET["Kode_matapelajaran"];

if($delete = mysqli_query($konek, "DELETE FROM matapelajaran WHERE Kode_matapelajaran='$Kode_matapelajaran'")){
	header("Location: matapelajaran.php");
	exit();
}
die ("Terdapat Kesalahan : ".mysqli_error($konek));

?>