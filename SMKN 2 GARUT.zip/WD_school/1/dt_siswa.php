				<thead>
					<tr>
						<th>NISN</th>
						<th>Siswa</th>
						<th>Tanggal Lahir</th>
						<th>Jenis Kelamin</th>
						<th>Telpon</th>
						<th>Alamat</th>
						<th>Jurusan</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$querymhs = mysqli_query ($konek, "SELECT NISN, Nama_siswa, DATE_FORMAT(Tanggal_Lahir, '%d-%m-%Y')as Tanggal_Lahir, JK, No_Telp, Alamat, kode_jurusan_Siswa, Nama_Jurusan FROM siswa INNER JOIN jurusan ON kode_jurusan_Siswa = Kode_Jurusan");
						if($querymhs == false){
							die ("Terjadi Kesalahan : ". mysqli_error($konek));
						}
							
						while ($mhs = mysqli_fetch_array ($querymhs)){
							
							echo "
								<tr>
									<td>$mhs[NISN]</td>
									<td>$mhs[Nama_siswa]</td>
									<td>$mhs[Tanggal_Lahir]</td>
									<td>
								";
									if($mhs["JK"] == "L"){
										echo "Laki - laki";
									}
									else{
										echo "Perempuan";
									}
							echo "
									</td>
									<td>$mhs[No_Telp]</td>
									<td>$mhs[Alamat]</td>
									<td>$mhs[Nama_Jurusan]</td>
									<td>
										<a href='#' class='open_modal' id='$mhs[NISN]'>Edit</a> |
										<a href='#' onClick='confirm_delete(\"siswa_delete.php?NISN=$mhs[NISN]\")'>Delete</a>
									</td>
								</tr>";
						}
					?>
				</tbody>