<?php

include "../koneksi.php";

$NISN 				= $_POST["NISN"];
$Nama_siswa		= $_POST["Nama_siswa"];
$Tanggal_Lahir		= $_POST["Tanggal_Lahir"];
$JK					= $_POST["JK"];
$No_Telp			= $_POST["No_Telp"];
$Alamat				= $_POST["Alamat"];
$kode_jurusan_Siswa	= $_POST["kode_jurusan_Siswa"];

if($edit = mysqli_query($konek, "UPDATE siswa SET Nama_siswa='$Nama_siswa', Tanggal_Lahir='$Tanggal_Lahir', JK='$JK', 
	No_Telp='$No_Telp', Alamat='$Alamat', kode_jurusan_Siswa='$kode_jurusan_Siswa' WHERE NISN='$NISN'")){
		header("Location: siswa.php");
		exit();
	}
die("Terdapat Kesalahan : ".mysqli_error($konek));

?>