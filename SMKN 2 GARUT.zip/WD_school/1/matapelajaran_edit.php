<?php

include "../koneksi.php";

$Kode_matapelajaran	= $_POST["Kode_matapelajaran"];
$Nama_matapelajaran	= $_POST["Nama_matapelajaran"];
/* $SKS				= $_POST["SKS"]; */

if($edit = mysqli_query($konek,"UPDATE matapelajaran SET Nama_matapelajaran='$Nama_matapelajaran' WHERE Kode_matapelajaran='$Kode_matapelajaran'")){
	header("Location: matapelajaran.php");
	exit();
}
die ("Terdapat Kesalahan : ". mysqli_error($konek));

?>