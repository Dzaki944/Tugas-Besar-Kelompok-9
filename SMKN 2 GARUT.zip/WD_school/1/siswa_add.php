<?php
include "../koneksi.php";

$NISN 				= $_POST["NISN"];
$Nama_siswa		= $_POST["Nama_siswa"];
$Tanggal_Lahir 		= $_POST["Tanggal_Lahir"];
$JK 				= $_POST["JK"];
$Alamat 			= $_POST["Alamat"];
$No_Telp 			= $_POST["No_Telp"];
$kode_jurusan_Siswa 	= $_POST["kode_jurusan_Siswa"];

if ($add = mysqli_query($konek, "INSERT INTO siswa (NISN, Nama_siswa, Tanggal_Lahir, JK, Alamat, No_Telp, kode_jurusan_Siswa) VALUES 
	('$NISN', '$Nama_siswa', '$Tanggal_Lahir', '$JK', '$Alamat', '$No_Telp', '$kode_jurusan_Siswa')")){
		header("Location: siswa.php");
		exit();
	}
die ("Terdapat kesalahan : ". mysqli_error($konek));

?>