<?php

include "../koneksi.php";

$Kode_matapelajaran	= $_POST["Kode_matapelajaran"];
$Nama_matapelajaran	= $_POST["Nama_matapelajaran"];
/* $SKS				= $_POST["SKS"]; */

if($add = mysqli_query($konek,"INSERT INTO matapelajaran (Kode_matapelajaran, Nama_matapelajaran) VALUES ('$Kode_matapelajaran', '$Nama_matapelajaran')")){
	header("Location: matapelajaran.php");
	exit();
}
die ("Terdapat Kesalahan : ". mysqli_error($konek));

?>