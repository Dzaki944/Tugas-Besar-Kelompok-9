<?php

include "../koneksi.php";

$NIP	= $_GET["NIP"];

if($delete = mysqli_query ($konek, "DELETE FROM Guru WHERE NIP='$NIP'")){
	header("Location: Guru.php");
	exit();
}
die ("Terdapat Kesalahan : ".mysqli_error($konek));

?>