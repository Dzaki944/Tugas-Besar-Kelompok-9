				<thead>
					<tr>
						<th>NIP</th>
						<th>Guru</th>
						<th>Tanggal Lahir</th>
						<th>Jenis Kelamin</th>
						<th>Telpon</th>
						<th>Alamat</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$queryGuru = mysqli_query ($konek, "SELECT NIP, Nama_Guru, DATE_FORMAT(Tanggal_Lahir, '%d-%m-%Y')as Tanggal_Lahir, JK, No_Telp, Alamat FROM Guru");
						if($queryGuru == false){
							die ("Terjadi Kesalahan : ". mysqli_error($konek));
						}
						while ($Guru = mysqli_fetch_array ($queryGuru)){
							
							echo "
								<tr>
									<td>$Guru[NIP]</td>
									<td>$Guru[Nama_Guru]</td>
									<td>$Guru[Tanggal_Lahir]</td>
									<td>
								";
									if($Guru["JK"] == "L"){
										echo "Laki - laki";
									}
									else{
										echo "Perempuan";
									}
							echo "
									</td>
									<td>$Guru[No_Telp]</td>
									<td>$Guru[Alamat]</td>
									<td>
										<a href='#' class='open_modal' id='$Guru[NIP]'>Edit</a> |
										<a href='#' onClick='confirm_delete(\"Guru_delete.php?NIP=$Guru[NIP]\")'>Delete</a>
									</td>
								</tr>";
						}
					?>
				</tbody>