<?php

include "../koneksi.php";

$Kode_matapelajaran	= $_GET["Kode_matapelajaran"];

$querymatapelajaran = mysqli_query($konek, "SELECT * FROM matapelajaran WHERE Kode_matapelajaran='$Kode_matapelajaran'");
if($querymatapelajaran == false){
	die ("Terjadi Kesalahan : ". mysqli_error($konek));
}
while($matapelajaran = mysqli_fetch_array($querymatapelajaran)){

?>
	
	<script src="../aset/plugins/daterangepicker/moment.min.js"></script>
	<script src="../aset/plugins/daterangepicker/daterangepicker.js"></script>
	<!-- page script -->
    <script>
      $(function () {	
		// Daterange Picker
		  $('#Tanggal_Lahir2').daterangepicker({
			  singleDatePicker: true,
			  showDropdowns: true,
			  format: 'YYYY-MM-DD'
		  });
      });
    </script>
<!-- Modal Popup Guru -->
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title">Edit MataPelajaran</h4>
					</div>
					<div class="modal-body">
						<form action="matapelajaran_edit.php" name="modal_popup" enctype="multipart/form-data" method="post">
							<div class="form-group">
								<label>Kode MataPelajaran</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<input name="Kode_matapelajaran" type="text" class="form-control" value="<?php echo $matapelajaran["Kode_matapelajaran"]; ?>" readonly />
									</div>
							</div>
							<div class="form-group">
								<label>MataPelajaran</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<input name="Nama_matapelajaran" type="text" class="form-control" value="<?php echo $matapelajaran["Nama_matapelajaran"]; ?>"/>
									</div>
							</div>
						<!--	<div class="form-group">
								<label>SKS</label>
									<div class="input-group">
										<div class="input-group-addon">
											<i class="fa fa-book"></i>
										</div>
										<input name="SKS" type="text" class="form-control" value="<?php echo $matapelajaran["SKS"]; ?>"/>
									</div>
							</div>-->
							<div class="modal-footer">
								<button class="btn btn-success" type="submit">
									Save
								</button>
								<button type="reset" class="btn btn-danger"  data-dismiss="modal" aria-hidden="true">
									Cancel
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			
			
<?php
			}

?>